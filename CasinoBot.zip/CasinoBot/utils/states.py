from aiogram.dispatcher.filters.state import State, StatesGroup


class UserStates(StatesGroup):
    amount = State()
    comment = State()

    id = State()


class AdminStates(StatesGroup):
    amount = State()