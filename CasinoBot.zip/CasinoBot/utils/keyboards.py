from aiogram import types


async def pay(url, amount, comment, id):
    keyboard = types.InlineKeyboardMarkup(row_width=3)
    keyboard.add(types.InlineKeyboardButton(text='🔗 Ссылка на оплату', url=url))
    keyboard.add(types.InlineKeyboardButton(text='✅ Проверить оплату', callback_data=f'check_{id}_{amount}_{comment}'))

    return keyboard


async def game():
    keyboard = types.InlineKeyboardMarkup(row_width=3)
    keyboard.add(types.InlineKeyboardButton(text='Сделать ставку', url="https://t.me/TetherBet_robot?start=start"))

    return keyboard


async def admin():
    keyboard = types.InlineKeyboardMarkup(row_width=3)
    keyboard.add(types.InlineKeyboardButton(text='⚡️ Посмотреть баланс', callback_data='balance'))
    keyboard.add(types.InlineKeyboardButton(text='💳 Пополнить баланс', callback_data='up_balance'))

    return keyboard