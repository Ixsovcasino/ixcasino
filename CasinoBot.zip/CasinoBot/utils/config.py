token = "7391996732:AAGo97r9S196TryU7Q1jJqGn0zXkdgCqds8" #BotFather

crypto_token = "15883:AARuP1JDXWwMQI8mSqPbaUZQOKWBORTWAHk" #CryptoAPI
 
admin_id = 7163707344 #Your ID
channel_id = -1002160511871 #GameChannel

bot_name = "Tebestcasinobot" # Example = TetherBet_robot

channel = "https://t.me/TestNetBetCasino"
chat = "t.me/"
rules = "t.me/"

directory = "/storage/emulated/0/КАЗИНО/CasinoBot"