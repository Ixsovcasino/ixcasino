import asyncio
from hedgesql import AioSqlite


class Database:
    def __init__(self, database):
        self.connection = AioSqlite(database)
        self.lock = asyncio.Lock()
        

    async def user_exists(self, user_id):
        async with self.lock:
            async with self.connection:
                 result = await self.connection.select_data('users', where=[{"user_id": user_id}], fetch="fetchall")

        return bool(len(result))


    async def add_user(self, user_id):
        async with self.lock:
            async with self.connection:
                await self.connection.insert_data('users', {'user_id': user_id})