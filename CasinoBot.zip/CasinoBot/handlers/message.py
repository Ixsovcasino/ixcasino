import asyncio, random, json

from loader import dp, bot, db, crypto
from aiogram import types
from aiogram.dispatcher import FSMContext
from utils.states import *
from utils.keyboards import *
from utils.filters import *
from utils.config import *


dp.filters_factory.bind(IsAdminFilter)


@dp.message_handler(commands=['start'])
async def handlerStart(message: types.Message, state: FSMContext):
    if (not await db.user_exists(user_id=message.from_user.id)):
        await db.add_user(user_id=message.from_user.id)

    msg = await message.answer("<b>⚡️ Введите сумму своей ставки в USDT.</b>\n\n<b><blockquote>❗️ Ставка должна быть больше 1.05$</blockquote></b>")
    
    await state.update_data(id=msg.message_id)

    await UserStates.amount.set()


@dp.message_handler(state=UserStates.amount)
async def handlerAmountState(message: types.Message, state: FSMContext):
    data = await state.get_data()

    await message.delete()

    try:
        if float(message.text) >= 1.05:
           await state.update_data(amount=message.text)

           await bot.edit_message_text(chat_id=message.from_user.id, message_id=data["id"], text="<b>💭 Введите комментарий для своей ставки.</b>\n\n<b><blockquote>❗️ Существующие игры - чет/нечет, больше/меньше</blockquote></b>")
           await UserStates.comment.set()

        else:
           await bot.edit_message_text(chat_id=message.from_user.id, message_id=data["id"], text="<b><blockquote>❗️ Ставка должна быть больше 1.05$</blockquote></b>")
           await state.finish()

    except:
        await bot.edit_message_text(chat_id=message.from_user.id, message_id=data["id"], text="<b><blockquote>❗️ Ставка должна быть больше 1.05$</blockquote></b>")
        await state.finish()


@dp.message_handler(state=UserStates.comment)
async def handlerAmountState(message: types.Message, state: FSMContext):
    data = await state.get_data()

    await message.delete()

    if message.text.lower().replace("ё", "е") in ["чет", "нечет", "больше", "меньше"]:
       invoice = await crypto.create_invoice(asset='USDT', amount=float(data["amount"]), paid_btn_url=f"https://t.me/{bot_name}", allow_anonymous=False, allow_comments=False)

       await bot.edit_message_text(chat_id=message.from_user.id, message_id=data["id"], text="<b>⚡️ Ваш счет для оплаты</b>", reply_markup=await pay(url=invoice.bot_invoice_url, amount=data["amount"], comment=message.text.lower().replace("ё", "е"), id=invoice.invoice_id))
       await state.finish()

    else:
       await bot.edit_message_text(chat_id=message.from_user.id, message_id=data["id"], text="<b><blockquote>❗️ Существующие игры - чет/нечет, больше/меньше</blockquote></b>")
       await state.finish()


@dp.callback_query_handler(text_contains="check_")
async def cryptoPay(callback_query: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()

    call = str(callback_query.data).replace("_", " ").split()

    invoice = await crypto.get_invoices(invoice_ids=call[1])
    
    if invoice[0].status == "paid":
       await callback_query.message.edit_text(text=f"<b><blockquote>⚡️ Сделана ставка на сумму {call[2]} $</blockquote></b>")

       await bot.send_message(chat_id=channel_id, text=f"<b>[💎] Новая ставка\n\n<blockquote>Никнейм игрока: {callback_query.from_user.full_name}</blockquote>\n\n<blockquote>Сумма ставки: {call[2]} $</blockquote>\n\n<blockquote>Исход ставки: {call[3]}</blockquote></b>")

       cube = await bot.send_dice(chat_id=channel_id)

       value = cube.dice.value
       
       try:
          if call[3] == "меньше" and value in [1, 2, 3] or call[3] == "больше" and value in [4, 5, 6] or call[3] == "нечет" and value in [1, 3, 5] or call[3] == "чет" and value in [2, 4, 6]:
            await crypto.transfer(user_id=callback_query.from_user.id, asset="USDT", amount=round(float(call[2]) * 1.8, 2), spend_id=''.join([random.choice('abc123' if i != 5 else 'ABC') for i in range(10)]))
          
            await callback_query.message.answer(f"<b><blockquote>⚡️ Победа! На ваш баланс в CryptoBot начислено {round(float(call[2]) * 1.8, 2)} $</blockquote></b>")
         
            await cube.reply(f"<b>Победа! Выпало значение {value}.</b>\n\n<blockquote><code>На баланс победителя была зачислена сумма в размере {round(float(call[2]) * 1.8, 2)}$.</code> <b><i>Бросай кубик заново и испытай свою удачу!</i></b></blockquote>\n\n<b><a href='{rules}'>Правила</a></b> | <b><a href='{channel}'>Новостной Канал</a></b> | <b><a href='{chat}'>Наш Чат</a></b>", reply_markup=await game())

          else:
            await cube.reply(f"<b>Проигрыш! Выпало значение {value}.</b>\n\n<blockquote><b><i>Бросай кубик заново и испытай свою удачу!</i></b></blockquote>\n\n<b><a href='{rules}'>Правила</a></b> | <b><a href='{channel}'>Новостной Канал</a></b> | <b><a href='{chat}'>Наш Чат</a></b>", reply_markup=await game())

        
       except:
            await callback_query.message.answer(f"<b><blockquote>⚡️ Победа! На ваш баланс в CryptoBot будет начислено {round(float(call[2]) * 1.8, 2)} $ администрацией вручную</blockquote></b>")
         
            await cube.reply(f"<b>Победа! Выпало значение {value}.</b>\n\n<blockquote><code>Сумма в размере {round(float(call[2]) * 1.8, 2)}$ будет зачислена администрацией вручную.</code> <b><i>Бросай кубик заново и испытай свою удачу!</i></b></blockquote>\n\n<b><a href='{rules}'>Правила</a></b> | <b><a href='{channel}'>Новостной Канал</a></b> | <b><a href='{chat}'>Наш Чат</a></b>", reply_markup=await game())

    else:
       await callback_query.message.edit_text(text="<b><blockquote>❗️ Счет не оплачен!</blockquote></b>", reply_markup=await pay(url=invoice[0].bot_invoice_url, amount=call[2], comment=call[3], id=call[1]))


@dp.message_handler(commands=['admin'], is_admin=True)
async def handlerAdmin(message: types.Message, state: FSMContext):
    await message.answer("<b>🏡 Добро пожаловать в админ меню!</b>", reply_markup=await admin())


@dp.callback_query_handler(text='balance')
async def callbackBalance(callback_query: types.CallbackQuery, state: FSMContext):
    app = await crypto.get_balance()

    for balance in app:
        if balance.currency_code == 'USDT':
           usdt = balance.available

           break

    await callback_query.message.answer(f"<b>🔥 Ваш баланс: <code>{usdt} USDT</code></b>")


@dp.callback_query_handler(text='up_balance')
async def callbackUpBalance(callback_query: types.CallbackQuery):
    await callback_query.message.answer(f"<b>⚡️ Введите сумму пополнения в USDT.</b>\n\n<b><blockquote>❗️ Сумма должна быть больше 1.05$</blockquote></b>")
    await AdminStates.amount.set()


@dp.message_handler(state=AdminStates.amount)
async def handlerAdminState(message: types.Message, state: FSMContext):
    invoice = await crypto.create_invoice(asset='USDT', amount=float(message.text), paid_btn_url=f"https://t.me/{bot_name}", allow_anonymous=False, allow_comments=False)

    await message.answer(f"<b><a href='{invoice.bot_invoice_url}'>⚡️ Оплатить</a></b>")

    await state.finish()