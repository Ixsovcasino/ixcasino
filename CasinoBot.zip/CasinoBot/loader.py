import logging

from aiogram import Bot, Dispatcher
from aiogram.contrib.fsm_storage.memory import MemoryStorage

from aiocryptopay import AioCryptoPay, Networks

from utils.config import *
from utils.database.db import Database


bot = Bot(token=token, parse_mode='HTML', disable_web_page_preview=True)
storage = MemoryStorage()
dp = Dispatcher(bot=bot, storage=storage)

crypto = AioCryptoPay(token=crypto_token, network=Networks.TEST_NET)

db = Database(database=directory + "/utils/database/database.db")

logging.basicConfig(level=logging.INFO)