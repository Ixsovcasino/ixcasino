import handlers
from aiogram.utils.executor import start_polling
from loader import dp, bot, db


if __name__ == '__main__':
    start_polling(dp, skip_updates=False)